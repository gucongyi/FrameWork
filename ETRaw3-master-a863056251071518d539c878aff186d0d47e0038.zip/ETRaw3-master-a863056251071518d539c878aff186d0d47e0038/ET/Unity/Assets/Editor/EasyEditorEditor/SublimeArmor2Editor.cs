﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace EasyEditor
{
    [Groups("Attributes", "Methods")]
	[CustomEditor(typeof(SublimeArmor2))]
	public class SublimeArmor2Editor : EasyEditorBase
	{
	
	}
}