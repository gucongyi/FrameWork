using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

[Groups("")]
[CustomEditor(typeof(EnemyHolder))]
public class EnemyHolderEditor : EasyEditorBase
{

}