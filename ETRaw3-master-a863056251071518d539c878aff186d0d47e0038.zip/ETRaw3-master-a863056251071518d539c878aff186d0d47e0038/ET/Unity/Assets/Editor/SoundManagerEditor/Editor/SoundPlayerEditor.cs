﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace Company
{
	[Groups("Programmers Settings")]
	[CustomEditor(typeof(SoundPlayer))]
	public class SoundPlayerEditor : EasyEditorBase
	{
	
	}
}