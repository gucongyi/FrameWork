﻿namespace ETHotfix
{
	public interface ISerializeToEntity
	{
	}
}