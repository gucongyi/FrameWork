﻿namespace ETHotfix
{
	public enum EntityType
	{
		None,
		Scene,
		Session,
		UI,
		Config,
		Unit
	}
}