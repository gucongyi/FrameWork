﻿namespace ETHotfix
{
	public static class EventIdType
	{
		public const string InitSceneStart = "InitSceneStart";
        public const string CreateUIBreeding = "CreateUIBreeding";
    }
}