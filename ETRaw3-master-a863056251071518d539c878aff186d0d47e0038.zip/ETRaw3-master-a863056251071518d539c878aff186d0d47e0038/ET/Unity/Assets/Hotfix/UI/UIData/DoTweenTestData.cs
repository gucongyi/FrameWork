//this file is auto created by QuickCode,you can edit it 
//do not need to care initialization of ui widget any more 
//------------------------------------------------------------------------------
/**
* @author :
* date    :
* purpose :
*/
//------------------------------------------------------------------------------
using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using Quick.UI;

public class DoTweenTestData
{

	#region UI Variable Statement 
	public Transform transform; 
	public Image image_ImageMove; 
	public Button button_ButtonMoveImage; 
	public Image image_ImageRotate; 
	public Button button_ButtonRotate; 
	public Image image_ImageFade; 
	public Button button_ButtonFade; 
	public Image image_ImageMove1; 
	public Image image_ImageRotate1; 
	public Image image_ImageFade1; 
	public Button button_ButtonSequence; 
	public Slider slider_Slider; 
	public Button button_ButtonSlider; 
	#endregion 

	#region UI Variable Assignment 
	public void InitUI() 
	{
		//assign transform by your ui framework
		//transform = ; 
		image_ImageMove = transform.Find("ImageMove").GetComponent<Image>();
        button_ButtonMoveImage = transform.Find("ButtonMoveImage").GetComponent<Button>(); 
		image_ImageRotate = transform.Find("ImageRotate").GetComponent<Image>();
        button_ButtonRotate = transform.Find("ButtonRotate").GetComponent<Button>(); 
		image_ImageFade = transform.Find("ImageFade").GetComponent<Image>();
        button_ButtonFade = transform.Find("ButtonFade").GetComponent<Button>(); 
		image_ImageMove1 = transform.Find("ImageMove1").GetComponent<Image>(); 
		image_ImageRotate1 = transform.Find("ImageRotate1").GetComponent<Image>(); 
		image_ImageFade1 = transform.Find("ImageFade1").GetComponent<Image>();
        button_ButtonSequence = transform.Find("ButtonSequence").GetComponent<Button>(); 
		slider_Slider = transform.Find("Slider").GetComponent<Slider>();
        button_ButtonSlider = transform.Find("ButtonSlider").GetComponent<Button>(); 

	}
	#endregion 

}
