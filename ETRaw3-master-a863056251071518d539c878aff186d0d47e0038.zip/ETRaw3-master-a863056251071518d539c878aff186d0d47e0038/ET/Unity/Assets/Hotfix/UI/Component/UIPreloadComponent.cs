﻿using ETModel;
using System;
using UnityEngine;
using UnityEngine.UI;

namespace ETHotfix
{
    [ObjectSystem]
    public class UIPreloadComponentAwakeSystem : AwakeSystem<UIPreloadComponent>
    {
        public override void Awake(UIPreloadComponent self)
        {
            self.Awake();
        }
    }

    public class UIPreloadComponent : UIBaseComponent
    {
        private Text textNowBundle;
        private Text textNowBundleSize;
        private Text textNowBundleSizeLoaded;
        private Text textTotalSize;
        private Text textTotalProgress;
        private Text textTotalProgressPercent;
        private long totalsize;

        public void Awake()
        {
            ReferenceCollector rc = this.GetParent<UI>().GameObject.GetComponent<ReferenceCollector>();
            textNowBundle = rc.Get<GameObject>("NowBundle").GetComponent<Text>();
            textNowBundleSize = rc.Get<GameObject>("NowBundleSize").GetComponent<Text>();
            textNowBundleSizeLoaded = rc.Get<GameObject>("NowBundleSizeLoaded").GetComponent<Text>();
            textTotalSize = rc.Get<GameObject>("TotalSize").GetComponent<Text>();
            textTotalProgress = rc.Get<GameObject>("TotalProgress").GetComponent<Text>();
            textTotalProgressPercent = rc.Get<GameObject>("TotalProgressPercent").GetComponent<Text>();
        }

        public void Init(long totalSize)
        {
            totalsize = totalSize;
            textTotalSize.text = $"总大小：{totalSize}";
        }

        public void NewLoading(string name, long size)
        {
            textNowBundle.text = $"当前加载bundle的名字：{name}";
            textNowBundleSize.text = $"当前加载bundle的大小：{size}";

        }

        public void SizeLoaded(float loaded, long loadedTotal)
        {
            textNowBundleSizeLoaded.text = $"当前加载bundlle的已加载：{loaded}";
            textTotalProgress.text = $"总进度：{loadedTotal}";
            textTotalProgressPercent.text = $"总进度百分比：{loadedTotal / totalsize * 100}%";
        }


    }
}
