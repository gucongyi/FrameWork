﻿using System;
using System.Net;
using DG.Tweening;
using ETModel;
using UnityEngine;
using UnityEngine.UI;

namespace ETHotfix
{
	[ObjectSystem]
	public class UIDoTweenTestComponentStartSystem : StartSystem<UIDoTweenTestComponent>
	{
		public override void Start(UIDoTweenTestComponent self)
		{
			self.Start();
		}
	}
	
	public class UIDoTweenTestComponent : UIBaseComponent
	{
        private Transform trans;
        private DoTweenTestData doTweenTestData;

        private bool is1;
        private bool is2;
        private bool is3;
        private bool is4;
        private bool is5;

        private Tweener tween1;
        private Tweener tween2;
        private Tweener tween3;
        Sequence mySequence;
        private Tweener tween5;


        public void Start()
		{
            ReferenceCollector rc = this.GetParent<UI>().GameObject.GetComponent<ReferenceCollector>();
            trans= rc.Get<GameObject>("UIDoTweenTest").transform;
            doTweenTestData = new DoTweenTestData();
            doTweenTestData.transform = trans;
            doTweenTestData.InitUI();

            doTweenTestData.button_ButtonMoveImage.onClick.Add(OnButtonMoveImage);

            tween1 = doTweenTestData.image_ImageMove.GetComponent<RectTransform>().DOLocalMove(new Vector3(-541f, 300f), 1f);//只生成一次
            tween1.SetAutoKill(false);//不自动销毁，否则播不了反向
            tween1.Pause();//先不播放，用DOPlayForward播放。


            doTweenTestData.button_ButtonRotate.onClick.Add(OnButtonRotate);

            tween2 = doTweenTestData.image_ImageRotate.GetComponent<RectTransform>().DOLocalRotate(new Vector3(0f, 0f, 180f), 1f).From();//从目标到当前
            tween2.SetAutoKill(false);
            tween2.Pause();


            doTweenTestData.button_ButtonFade.onClick.Add(OnButtonFade);
            tween3 = doTweenTestData.image_ImageFade.DOFade(0, 1f).SetEase(Ease.InOutBack);//设置动画曲线
            tween3.SetAutoKill(false);
            tween3.Pause();
            doTweenTestData.button_ButtonSequence.onClick.Add(OnButtonSequence);
            var seqTween1= doTweenTestData.image_ImageMove1.GetComponent<RectTransform>().DOLocalMove(new Vector3(-541f, -125.6f), 0.5f);
            var seqTween2 = doTweenTestData.image_ImageRotate1.GetComponent<RectTransform>().DOLocalRotate(new Vector3(0f, 0f, 180f), 1f);
            var seqTween3 = doTweenTestData.image_ImageFade1.DOFade(0, 3f);
            //序列
            mySequence = DOTween.Sequence();
            mySequence.Append(seqTween1);
            mySequence.Join(seqTween2);//2将和1一起播放。
            mySequence.Append(seqTween3);
            mySequence.Pause();

            doTweenTestData.button_ButtonSlider.onClick.Add(OnButtonSlider);
            tween5 = doTweenTestData.slider_Slider.DOValue(0.8f, 1f).OnComplete(OnSliderPlayerComplete);//监听完成事件，只有正向的事件打印出来。
            tween5.SetAutoKill(false);
            tween5.Pause();
        }
        public void OnButtonMoveImage()
        {
            if (!is1)
            {
                doTweenTestData.image_ImageMove.GetComponent<RectTransform>().DOPlayForward();//DoPlay是只播放一次，下次再点击就不播了。
            }
            else
            {
                doTweenTestData.image_ImageMove.GetComponent<RectTransform>().DOPlayBackwards();
            }
            is1 = !is1;
        }
        public void OnButtonRotate()
        {
            if (!is2)
            {
                doTweenTestData.image_ImageRotate.GetComponent<RectTransform>().DOPlayForward();
            }
            else
            {
                doTweenTestData.image_ImageRotate.GetComponent<RectTransform>().DOPlayBackwards();
            }
            is2 = !is2;
        }
        public void OnButtonFade()
        {
            if (!is3)
            {
                doTweenTestData.image_ImageFade.DOPlayForward();
            }
            else
            {
                doTweenTestData.image_ImageFade.DOPlayBackwards();
            }
            is3 = !is3;
        }
        public void OnButtonSequence()
        {
            if (!is4)
            {
                mySequence.PlayForward();
            }
            else
            {
                mySequence.PlayBackwards();
            }
            is4 = !is4;
        }
        public void OnButtonSlider()
        {
            if (!is5)
            {
                doTweenTestData.slider_Slider.DOPlayForward();
            }
            else
            {
                doTweenTestData.slider_Slider.DOPlayBackwards();
            }
            is5 = !is5;
        }

        public void OnSliderPlayerComplete()
        {
            if (is5)
            {
                ZLog.Info($"动画正向播放完成");
            }
            else
            {
                ZLog.Info($"动画反向播放完成");
            }
        }

        public override void Dispose()
        {
            base.Dispose();
            tween1.Kill();
            tween2.Kill();
            tween3.Kill();
            tween5.Kill();
        }

    }
}
