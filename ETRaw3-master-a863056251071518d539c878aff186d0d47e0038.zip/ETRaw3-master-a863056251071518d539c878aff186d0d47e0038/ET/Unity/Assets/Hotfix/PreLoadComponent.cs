﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

namespace ETHotfix
{
    [ETModel.ObjectSystem]
    public class PreLoadComponentAwakeSystem : AwakeSystem<PreLoadComponent, string[]>
    {
        public override void Awake(PreLoadComponent self, string[] preLoadAssetBundleNames)
        {
            self.Awake(preLoadAssetBundleNames);
        }
    }

    public class PreLoadComponent : Component
    {
        string[] preLoadAssetBundleNames = null;
        ETModel.VersionConfig localVersionConfig;

        /// <summary>
        /// 所有预加载资源的总进度
        /// </summary>
        public Action<float> totalSizeProgress;
        public long totalSizeLoaded { private set; get; }
        private long totalSize;
        private class PreLoadAssetBundle
        {
            PreLoadComponent preLoadComponent;
            public PreLoadAssetBundle(PreLoadComponent preLoadComponent)
            {
                this.preLoadComponent = preLoadComponent;
            }
            public string name;
            public long size;
            public float progress;
            public Action<float, long> actionProgress;
            public void LoadProgress(float prog)
            {
                progress = prog;
                sizeLoaded = (long)(size * progress);

                actionProgress?.Invoke(sizeLoaded, preLoadComponent.totalSizeLoaded + sizeLoaded);
                Debug.Log($"name:{name},size:{size},sizeloaded:{sizeLoaded},totalSizeloaded:{preLoadComponent.totalSizeLoaded + sizeLoaded}");
            }
            public long sizeLoaded { private set; get; }
        }

        List<PreLoadAssetBundle> listPreload = new List<PreLoadAssetBundle>();
        PreLoadAssetBundle preLoadStruct;
        private int loadedCount = 0;
        private Text text;
        StringBuilder stringBuilder = new StringBuilder();
        UIPreloadComponent uiPreloadComponent;

        public async void Awake(string[] preLoadAssetBundleNames)
        {
            this.preLoadAssetBundleNames = preLoadAssetBundleNames;
            if (this.preLoadAssetBundleNames == null)
            {
                Debug.Log("预加载 资源为null");
                return;
            }
            // 对比本地的Version.txt
            string versionPath = Path.Combine(ETModel.PathHelper.AppHotfixResPath, "Version.txt");
            if (File.Exists(versionPath))
            {
                localVersionConfig = JsonHelper.FromJson<ETModel.VersionConfig>(File.ReadAllText(versionPath));
                localVersionConfig.EndInit();
            }
            else
            {
                versionPath = Path.Combine(ETModel.PathHelper.AppResPath4Web, "Version.txt");
                using (ETModel.UnityWebRequestAsync request = ETModel.ComponentFactory.Create<ETModel.UnityWebRequestAsync>())
                {
                    try
                    {
                        await request.DownloadAsync(versionPath);
                        localVersionConfig = JsonHelper.FromJson<ETModel.VersionConfig>(request.Request.downloadHandler.text);
                        localVersionConfig.EndInit();
                    }
                    catch (System.Exception e)
                    {
                        Log.Debug(e.ToString());
                        localVersionConfig = null;
                    }
                }
            }
            loadedCount = 0;
            listPreload.Clear();
            totalSize = 0;
            foreach (var assetBundleName in preLoadAssetBundleNames)
            {
                string[] dependencies = ETModel.ResourcesHelper.GetSortedDependencies(assetBundleName.ToLower());
                foreach (string dependency in dependencies)
                {
                    if (string.IsNullOrEmpty(dependency))
                    {
                        continue;
                    }
                    var size = localVersionConfig.FileInfoDict[dependency].Size;
                    listPreload.Add(new PreLoadAssetBundle(this)
                    {
                        name = dependency,
                        size = size,
                        progress = 0,
                    });
                    totalSize += size;
                }
            }
            await Game.Scene.GetComponent<UIComponent>().CreateAsync(UIType.UIPreload);
            uiPreloadComponent = Game.Scene.GetComponent<UIComponent>().Get(UIType.UIPreload).UiComponent as UIPreloadComponent;
            uiPreloadComponent.Init(totalSize);
            Debug.Log("预加载 开始");
            await Execute();
            Debug.Log("预加载 结束");
        }

        public async Task Execute()
        {
            foreach (var preload in listPreload)
            {
                if (preload == null || string.IsNullOrEmpty(preload.name))
                {
                    continue;
                }
                preLoadStruct = preload;
                preLoadStruct.actionProgress = uiPreloadComponent.SizeLoaded;
                uiPreloadComponent.NewLoading(preLoadStruct.name, preLoadStruct.size);
                //await ETModel.Game.Scene.GetComponent<ETModel.ResourcesComponent>().LoadBundleAsync(preLoadStruct.name, true);
                await ETModel.Game.Scene.GetComponent<ETModel.ResourcesComponent>().LoadOneBundleAsync(preLoadStruct.name, preLoadStruct.LoadProgress);
                loadedCount++;
                totalSizeLoaded += preLoadStruct.size;
            }
        }
    }
}