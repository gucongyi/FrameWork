﻿using System;
using System.IO;
using System.Threading.Tasks;
using Company.Cfg;
using ETModel;
using UniRx.Async;
using UnityEngine;
using UnityEngine.UI;

namespace ETHotfix
{
    public static class Init
    {

        public static async void Start()
        {
            try
            {

                Debug.Log("Begin ETHotfix.Init.Start");
                Game.Scene.ModelScene = ETModel.Game.Scene;
                ////Test
                //UnityEngine.Sprite sprite = await ABManager.GetAssetAsync<UnityEngine.Sprite>(Hotfix.ABMapping.ArrowUp1);
                //Debug.Log($"{Hotfix.ABMapping.ArrowUp1}:{sprite.name}");
                GameSoundPlayer.Instance.PlayBgMusic("BgMusicHotfix");
                GameSoundPlayer.Instance.PlaySoundEffect("laugh2D");
                GameSoundPlayer.Instance.PlaySoundEffect("water", Vector3.zero);
                // 注册热更层回调
                ETModel.Game.Hotfix.Update = () => { Update(); };
                ETModel.Game.Hotfix.LateUpdate = () => { LateUpdate(); };
                ETModel.Game.Hotfix.OnApplicationQuit = () => { OnApplicationQuit(); };
                ETModel.Game.Hotfix.OnApplicationFocus = () => { OnApplicationFocus(); };

                Game.Scene.AddComponent<UIComponent>();


                //预加载一些bundle
                string[] preLoadAssetBundleNames = new string[]
                {
                    "tabtoydata.unity3d",
                    "feed.unity3d",
                    "fonts.unity3d",
                    "homeui.unity3d",
                };
                Game.Scene.AddComponent<PreLoadComponent, string[]>(preLoadAssetBundleNames);
                //return;

                await ETModel.Game.Scene.GetComponent<ResourcesComponent>().LoadBundleAsync<UnityEngine.Sprite>("icon.unity3d");
                //解析数据表
                var tabtoyText = await ABManager.GetAssetAsync<TextAsset>(Hotfix.ABMapping.tabtoyData);
                //读取
                MemoryStream ms = null;
                var il = new ILSerial();
                Config configTabtoy = il.ReadFileBytes<Config>(tabtoyText.bytes, out ms);
                StaticTool.TabToyDataConfig = configTabtoy;
                ms.Close();
                var define = configTabtoy.Test[0];
                Debug.LogError($"热更层 解析数据表不建议使用float,float数组会导致解析错误，最好用int32替代");
                Debug.LogError($"热更层 数据表中string要加\"\",否则会解析出错");
                Debug.LogError($"热更层 Test define.TestInt:{define.TestInt} define.TestLong:{define.TestLong}");
                Debug.LogError($"热更层 Test define.TestFloat:{define.TestFloat}");
                Debug.LogError($"热更层 Test define.TestString:{define.TestString}");
                Debug.LogError($"热更层 Test define.TestIntArr:{define.TestIntArr[0]} {define.TestIntArr[1]} {define.TestIntArr[2]} {define.TestIntArr[3]} {define.TestIntArr[4]} {define.TestIntArr[5]}");
                Debug.LogError($"热更层 Test define.TestFloat2:{define.TestFloat2}");
                Debug.LogError($"热更层 Test define.TestStringArr:{define.TestStringArr[0]} {define.TestStringArr[1]} {define.TestStringArr[2]}");
                Debug.LogError($"热更层 Test define.TestEnum0:{define.TestEnum0} define.TestEnum1:{define.TestEnum1}");
                Debug.LogError($"热更层 Test define.TestClass:{define.TestClass.DropID} {define.TestClass.DropNumber}");

                //初始化ab字典
                ETModel.Game.Scene.GetComponent<ResourcesComponent>().InitDicABRequest();
                ////测试DoTween插件
                //UI uiDoTweenTest = await Game.Scene.GetComponent<UIComponent>().CreateAsync(UIType.UIDoTweenTest);
                Debug.Log("Begin ETHotfix.Init.Start UIType.UIFrameShow");
                await Game.Scene.GetComponent<UIComponent>().CreateAsync(UIType.UIFrameShow);
                Debug.Log("End ETHotfix.Init.Start UIType.UIFrameShow");
                Debug.Log("Begin ETHotfix.Init.Start UIType.UILogin");
                UI ui = await Game.Scene.GetComponent<UIComponent>().CreateAsync(UIType.UILogin);
                Debug.Log("End ETHotfix.Init.Start UIType.UILogin");
                ETModel.Game.Scene.GetComponent<ETModel.UIComponent>().Remove(ETModel.UIType.UILoading);//关闭进度条
                Debug.Log("End ETHotfix.Init.Start Remove ETModel.UIType.UILoading");

            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        private async static Task PreLoad()
        {
            var list = new System.Collections.Generic.List<string>() { };
            var progress = 0f;
            var res = ETModel.Game.Scene.GetComponent<ResourcesComponent>();
            for (int i = 0; i < list.Count; i++)
            {
                await res.LoadBundleAsync(list[i], true);
                progress = (i + 1) * 100f / list.Count;
            }
        }


        public static void Update()
        {
            try
            {
                Game.EventSystem.Update();
            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        public static void LateUpdate()
        {
            try
            {
                Game.EventSystem.LateUpdate();
            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        public static void OnApplicationQuit()
        {
            Game.Close();
            StaticTool.Dispose();
        }

        public static void OnApplicationFocus()
        {

        }
    }
}