﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace ETModel
{
    public class CrossDomainHelper
    {
        //跑动的时候头马的速度，用来跨域调用，上层摄像机调用热更层的东西
        public static float FirstHorseSpeed;
        public static Transform FirstHorseTrans;
    }
}

