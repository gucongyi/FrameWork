﻿namespace ETModel
{
	/// <summary>
	/// 一般使用事件名+变量名
	/// </summary>
	public enum EnvKey
	{
		ChannelError
	}
}