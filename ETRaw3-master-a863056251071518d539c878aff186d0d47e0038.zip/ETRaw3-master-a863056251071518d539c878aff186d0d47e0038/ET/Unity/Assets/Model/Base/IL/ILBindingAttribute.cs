﻿using System;

namespace ETModel
{
	[AttributeUsage(AttributeTargets.Class, Inherited = false)]
	public class ILBindingAttribute : Attribute
	{
	}
}