﻿using System;

namespace ETModel
{
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ObjectSystemAttribute: Attribute
	{
	}
}