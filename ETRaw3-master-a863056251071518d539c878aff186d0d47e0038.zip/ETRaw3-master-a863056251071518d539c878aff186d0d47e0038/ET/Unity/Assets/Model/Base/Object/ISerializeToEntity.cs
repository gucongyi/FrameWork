﻿namespace ETModel
{
	public interface ISerializeToEntity
	{
	}
}