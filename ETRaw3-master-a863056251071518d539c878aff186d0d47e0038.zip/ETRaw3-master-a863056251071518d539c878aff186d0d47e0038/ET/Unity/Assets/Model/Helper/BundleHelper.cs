﻿using System;
using System.Threading.Tasks;
using UnityEngine;

namespace ETModel
{
    public static class BundleHelper
    {
        public static async Task DownloadBundle()
        {
            await StartDownLoadResources();
        }
        public static async Task<bool> IsGameVersionCodeEqual()
        {
            UnityWebRequestAsync webRequestAsync = ComponentFactory.Create<UnityWebRequestAsync>();
            try
            {
                string versionCode = ETModel.Define.isInnetNet ?
                    GlobalConfigComponent.Instance.GlobalProto.VersionCodeInner :
                    GlobalConfigComponent.Instance.GlobalProto.VersionCodeOuter;
                //下载VersionCode
                await webRequestAsync.DownloadAsync(versionCode);
                var remoteVersionGameCode = webRequestAsync.Request.downloadHandler.text;
                webRequestAsync.Dispose();
                //比较VersionCode
                ZLog.Info($"local versionGameCode:{ETModel.Define.localVersionGameCode},remote versionGameCode:{remoteVersionGameCode}");
                if (string.Equals(remoteVersionGameCode, ETModel.Define.localVersionGameCode))
                {
                    return true;
                }
                //while (!VideoUtil.videoFinished)
                //    await UniRx.Async.UniTask.DelayFrame(1);
                TipsDifferentVersion();
            }
            catch (Exception e)
            {
                if (e.Message.Contains("request error"))
                {
                    webRequestAsync.Dispose();
                    ZLog.Info($"load VersionGameCode error:'{e.Message}'");
                }
            }
            return false;
        }

        /// <summary>
        /// 提示版本号不一样
        /// </summary>
        private static void TipsDifferentVersion()
        {
            UIComponent uiComponent = Game.Scene.GetComponent<UIComponent>();
            UI uiLoading = uiComponent.Get(UIType.UILoading);
            var uiLoadingComponent = uiLoading.GetComponent<UILoadingComponent>();
            var trans = uiLoadingComponent.view.transform.Find("ConfirmWindowVersion");
            var tip = new UIUpdateVersionTip(trans);
            tip.OnConfirm = () =>
            {
                ETModel.Define.QuitApplication();
            };
        }

        public static async Task StartDownLoadResources()
        {
            if (Define.isUseAssetBundle)
            {
                try
                {
                    using (BundleDownloaderComponent bundleDownloaderComponent = Game.Scene.GetComponent<BundleDownloaderComponent>())
                    {
                        var t = bundleDownloaderComponent.LoadInfo();

                        UIComponent uiComponent = Game.Scene.GetComponent<UIComponent>();
                        UI uiLoading = uiComponent.Get(UIType.UILoading);
                        var uiLoadingComponent = uiLoading.GetComponent<UILoadingComponent>();
                        uiLoadingComponent.DownLoadInfo = bundleDownloaderComponent.DownloadInfo;
                        bundleDownloaderComponent.BundleRealProgress = uiLoadingComponent.BundleRealDownload;
                        bundleDownloaderComponent.BundleEachFrameProgress = uiLoadingComponent.BundleDownloadFrames;
                        uiLoadingComponent.UpdateProgress = bundleDownloaderComponent.UpdateProgress;
                        var needDown = await t;
                        if (needDown)
                        {
                            var x1 = uiLoadingComponent.DownLoadInfo.TotalSize / 1024;
                            var x = x1 / 1024f;

                            //如果大于1m 不是wifi才弹提示
                            if (x > 1 /*&& Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork*/)
                            {
                                //while (!VideoUtil.videoFinished)
                                //    await UniRx.Async.UniTask.DelayFrame(1);
                                var actionEvent = new ActionEvent();
                                //弹提示.
                                var trans = uiLoadingComponent.view.transform.Find("ConfirmWindow");
                                var tip = new UIUpdateTip(trans);
                                //取两位小数
                                int j = (int)(x * 100);
                                x = j / 100f;
                                tip.SetInfo($"当前不是wifi环境, 更新需要消耗{x}M流量,\n是否更新 ? (点击取消将退出游戏)");
                                tip.OnConfirm = () =>
                                {
                                    trans.gameObject.SetActive(false);
                                    actionEvent.Dispatch();
                                };
                                tip.OnCancel = () =>
                                {
                                    Define.QuitApplication();
                                    return;
                                };

                                await actionEvent;
                            }
                        }
                        await bundleDownloaderComponent.Down();
                        uiLoadingComponent.DownLoadInfo.IsEnd = true;
                    }

                    await Game.Scene.GetComponent<ResourcesComponent>().LoadOneBundleAsync("StreamingAssets");

                    ResourcesComponent.AssetBundleManifestObject = (AssetBundleManifest)Game.Scene.GetComponent<ResourcesComponent>().GetAsset("StreamingAssets", "AssetBundleManifest");
                }
                catch (Exception e)
                {
                    Log.Error(e);
                }

            }
        }
    }
}
