﻿using Company;
using System;
using System.Threading;
using UniRx.Async;
using UnityEngine;
public class Init : MonoBehaviour
{
    public string versionGameCode;
    public string GameShowVersion;
    public GameObject goDebug;
    public bool isShowDebugWindow;
    /// <summary>
    /// 是否显示FPS
    /// </summary>
    public bool isShowFPS;
    public bool isUseAssetBundle;
    //默认不选，从服务器下载
    public bool isABNotFromServer;
    public bool isABUsedYunSever;
    public string selfResourceServerIpAndPort;
    public int TargetFrameRate;
    /*#if UNITY_ANDROID
            private int scaleWidth = 0;
            private int scaleHeight = 0;
            public void setDesignContentScale()
            {
                if (scaleWidth == 0 && scaleHeight == 0)
                {
                    int width = Screen.currentResolution.width;
                    int height = Screen.currentResolution.height;
                    int designWidth = 1136;
                    int designHeight = 640;
                    float s1 = (float)designWidth / (float)designHeight;
                    float s2 = (float)width / (float)height;
                    if (s1 < s2)
                    {
                        designWidth = (int)Mathf.FloorToInt(designHeight * s2);
                    }
                    else if (s1 > s2)
                    {
                        designHeight = (int)Mathf.FloorToInt(designWidth / s2);
                    }
                    float contentScale = (float)designWidth / (float)width;
                    if (contentScale < 1.0f)
                    {
                        scaleWidth = designWidth;
                        scaleHeight = designHeight;
                    }
                }
                if (scaleWidth > 0 && scaleHeight > 0)
                {
                    if (scaleWidth % 2 == 0)
                    {
                        scaleWidth += 1;
                    }
                    else
                    {
                        scaleWidth -= 1;
                    }
                    Screen.SetResolution(scaleWidth, scaleHeight, true);
                }
            }

            void OnApplicationPause(bool paused)
            {
                if (paused)
                {
                }
                else
                {
                    setDesignContentScale();
                }
            }
    #endif*/
    private async void Start()
    {
        if (isShowDebugWindow)
        {
            goDebug.SetActive(true);
        }
        else
        {
            goDebug.SetActive(false);
        }

        if (isShowFPS)
        {
            ResourcesHelper.InstantiatePrefabFromResourceSetDefault("UIFrameShow", UIRoot.instance.GetUIRootCanvasTop().transform);
        }

        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Application.targetFrameRate = TargetFrameRate;
        StaticData.IsABNotFromServer = isABNotFromServer;
        StaticData.isABUsedYunSever = isABUsedYunSever;
        StaticData.SelfResourceServerIpAndPort = selfResourceServerIpAndPort;
        StaticData.localVersionGameCode = versionGameCode;
        StaticData.GameShowVersion = GameShowVersion;
        try
        {
            //播放背景音乐
            GameSoundPlayer.Instance.PlayBgMusic("ExampleBgMusic");
            StaticData.isUseAssetBundle = isUseAssetBundle;
            DontDestroyOnLoad(gameObject);
            gameObject.AddComponentIfNull<GlobalConfigComponent>();
            gameObject.AddComponentIfNull<ResourcesComponent>();
            BundleDownloaderComponent bundleDownloaderComponent=gameObject.AddComponentIfNull<BundleDownloaderComponent>();
            //Game.EventSystem.Run(EventIdType.LoadingBegin);//打开进度条，最外层的
            var IsGameVersionCodeEqual = await BundleHelper.IsGameVersionCodeEqual();
            if (!IsGameVersionCodeEqual)
            {
                return;
            }
            // 下载ab包
            await BundleHelper.DownloadBundle();
            GameObject.Destroy(bundleDownloaderComponent);

            //AB初始化
            ABManager.Init();
            //数据表格解析
            ParseExcelData parseExcelData = new ParseExcelData();
            StaticData.configExcel = parseExcelData.Init();
            //Test Excel
            StaticData.configExcel.GetAvatarByID(1);
            Debug.Log($"Avatar1 Name:{StaticData.configExcel.GetAvatarByID(1).Name} Vertical:{StaticData.configExcel.GetVertical().GetPlantBarnBagAllGridCount}");
            //下载好了，声音ab绑定到固定的地方
            await ResetSoundPlayers();
            GameSoundPlayer.Instance.PlayBgMusic("BgLobby1");
            //GameSoundPlayer.Instance.PlaySoundEffect("PrintPhotos");
            GameObject go=ABManager.GetAsset<GameObject>("UILogin");
            ResourcesHelper.InstantiatePrefabFromABSetDefault(go);
            await UniTask.DelayFrame(1);
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
    }

    private static async System.Threading.Tasks.Task ResetSoundPlayers()
    {
        //更新音乐
        var goMusicPlayer = GameObject.Find("Global/GameSoundPlayer/MusicPlayer");
        var goEffectPlayer = GameObject.Find("Global/GameSoundPlayer/SFXPlayer");
        var soundPlayerMusic = goMusicPlayer.GetComponent<SoundPlayer>();
        var soundPlayerEffect = goEffectPlayer.GetComponent<SoundPlayer>();
        var goMusicList = await ABManager.GetAssetAsync<GameObject>("MusicList");
        goMusicList = GameObject.Instantiate(goMusicList);
        goMusicList.transform.parent = goMusicPlayer.transform;
        soundPlayerMusic.soundLists[0] = goMusicList.GetComponent<SoundList>();
        var goSound2dEffectList = await ABManager.GetAssetAsync<UnityEngine.GameObject>("SoundList2D");
        var goSound3dEffectList = await ABManager.GetAssetAsync<UnityEngine.GameObject>("SoundList3D");
        goSound2dEffectList = GameObject.Instantiate(goSound2dEffectList);
        goSound3dEffectList = GameObject.Instantiate(goSound3dEffectList);
        goSound2dEffectList.transform.parent = goEffectPlayer.transform;
        goSound3dEffectList.transform.parent = goEffectPlayer.transform;
        soundPlayerEffect.soundLists[0] = goSound2dEffectList.GetComponent<SoundList>();
        soundPlayerEffect.soundLists[1] = goSound3dEffectList.GetComponent<SoundList>();
        //重新初始话
        soundPlayerMusic.soundLists[0].InitializeAudioSourcePools();
        soundPlayerEffect.soundLists[0].InitializeAudioSourcePools();
        soundPlayerEffect.soundLists[1].InitializeAudioSourcePools();
    }


    private void Update()
    {
        
    }

    private void LateUpdate()
    {
        
    }

    private void OnApplicationQuit()
    {
        
    }

    private void OnApplicationFocus(bool focus)
    {
        if (focus)
        {
            
        }
    }
}