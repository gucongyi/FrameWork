﻿
public class GlobalProto
{
    public string VersionUploadSelfResUrl;
    //大版本
    public string BigVersionCode;
    public string AssetBundleServerUrl;
    


    public string GetUrl()
    {
        string url = this.AssetBundleServerUrl;
        url += StaticData.ParentResABDirectory + "/";
#if UNITY_ANDROID
        url += "Android/";
#elif UNITY_IOS
			url += "IOS/";
#elif UNITY_WEBGL
			url += "WebGL/";
#else
			url += "PC/";
#endif
        //Log.Debug(url);
        return url;
    }
}
