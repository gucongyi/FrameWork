﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasScalerController : MonoBehaviour {
    
    private void Start()
    {
        var arrayCanvas=transform.GetComponentsInChildren<Canvas>();
        for (int i = 0; i < arrayCanvas.Length; i++)
        {
            GetCur_scaleFactor(arrayCanvas[i]);
        }
    }

    /// <summary>
    /// 根据标准分辨率比率获取当前的需要使用的比例因子
    /// </summary>
    private void GetCur_scaleFactor(Canvas canvas) {


        float f = (float)Screen.height / (float)Screen.width;

        if (f < 1.775)
        {
            canvas.GetComponent<CanvasScaler>().matchWidthOrHeight = 1;
        }
        else
        {
            canvas.GetComponent<CanvasScaler>().matchWidthOrHeight = 0;
        }
        Debug.Log($"canvas name:{canvas.name} canvas.scaleFactor:{canvas.scaleFactor}");
    }
}
