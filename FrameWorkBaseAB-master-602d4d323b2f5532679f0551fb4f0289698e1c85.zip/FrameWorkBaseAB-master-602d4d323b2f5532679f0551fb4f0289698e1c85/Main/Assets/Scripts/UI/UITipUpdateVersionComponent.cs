﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UITipUpdateVersionComponent : MonoBehaviour
{
    public Button ButtonOk;
    // Start is called before the first frame update
    void Start()
    {
        ButtonOk.onClick.RemoveAllListeners();
        ButtonOk.onClick.AddListener(OnButtonOkClick);
    }

    private void OnButtonOkClick()
    {
        StaticData.QuitApplication();
        Destroy(gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
