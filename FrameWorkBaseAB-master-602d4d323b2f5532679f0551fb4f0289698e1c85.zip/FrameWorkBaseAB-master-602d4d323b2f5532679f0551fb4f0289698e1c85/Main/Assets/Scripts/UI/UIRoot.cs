﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIRoot : MonoBehaviour
{
    Canvas canvas;
    Canvas canvasTop;
    Camera uiCamera;
    public static UIRoot instance;
    void Awake()
    {
        if (instance != null)
        {
            Destroy(instance.gameObject);
        }
        instance = this;
        DontDestroyOnLoad(gameObject);
        canvas = GameObject.Find("Canvas").GetComponent<Canvas>();
        canvasTop= GameObject.Find("CanvasTop").GetComponent<Canvas>();
        uiCamera = canvas.worldCamera;
    }

    public Canvas GetUIRootCanvas()
    {
        return canvas;
    }
    public Canvas GetUIRootCanvasTop()
    {
        return canvasTop;
    }
    public Camera GetUIRootCamera()
    {
        return uiCamera;
    }




    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
