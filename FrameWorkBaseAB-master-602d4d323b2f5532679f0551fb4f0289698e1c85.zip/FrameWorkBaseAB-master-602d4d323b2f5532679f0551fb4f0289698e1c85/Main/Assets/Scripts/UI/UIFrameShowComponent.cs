﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIFrameShowComponent : MonoBehaviour
{
    public Text TextShow;
    private Transform trans;
    int TimesEachSeconds;
    float currTime;
    // Start is called before the first frame update
    void Start()
    {
        TimesEachSeconds = 0;
        currTime = 0f;
        TextShow.text = Application.targetFrameRate + " FPS";//初始值
    }

    // Update is called once per frame
    void Update()
    {
        currTime += Time.unscaledDeltaTime;
        TimesEachSeconds++;
        if (currTime >= 1f)
        {
            TextShow.text = TimesEachSeconds + " FPS " + Mathf.Round(10000f / TimesEachSeconds) / 10 + "ms";
            TimesEachSeconds = 0;
            currTime = 0f;
        }
    }
}
