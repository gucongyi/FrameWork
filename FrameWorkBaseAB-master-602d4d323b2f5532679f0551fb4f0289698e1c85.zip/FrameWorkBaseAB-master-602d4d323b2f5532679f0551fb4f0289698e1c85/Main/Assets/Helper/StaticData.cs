﻿using Company.Cfg;
using System.Collections.Generic;
using System.Threading.Tasks;
public static class StaticData
{
    public static string ParentResABDirectory;
    public static string localVersionGameCode;
    public static string GameShowVersion;
    /// <summary>
    /// 下载buddle,Editor也用ab.
    /// </summary>
    public static bool isUseAssetBundle = false;
    public static bool IsABNotFromServer = false;
    public static string SelfResourceServerIpAndPort;
    public static bool isUseStreamingAssetRes = false;
    public static bool isNotWifiDownloadClick;
    public static bool isNotWifiDownload;
    public static Config configExcel;
    public static bool isABUsedYunSever;
    public static void QuitApplication()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
            UnityEngine.Application.Quit();
#endif
    }
}