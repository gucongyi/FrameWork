﻿
using ETModel;
using System;
using UnityEngine;
using UnityEngine.UI;
public class TimeCountDownComponent : MonoBehaviour,IDisposable
{
    Action OnActionOnSecondPass;
    Text textShowTimeOneMinute;
    float timeCountDown;
    Action OnTimeCountDownCompelete;
    float timeCount;
    float timeOneSecondCount;
    float timeOneMinute;
    string stringFormatShow;
    string stringColorCode;
    public void Update()
    {
        if (timeCount <= 0f)
        {
            return;
        }
        timeCount -= Time.deltaTime;
        timeOneSecondCount += Time.deltaTime;
        timeOneMinute += Time.deltaTime;
        if (timeOneSecondCount > 1f)
        {
            timeOneSecondCount = 0f;
            showTime();
        }
        if (timeOneMinute > 60)
        {
            timeOneMinute = 0;
        }
        if (timeCount <= 0f)
        {
            //倒计时时间到了，回调
            OnTimeCountDownCompelete?.Invoke();
            showTime();
        }
    }
    public void Init(float timeCountDown, Action OnTimeCountDownCompelete)
    {
        this.timeCountDown = timeCountDown;
        this.OnTimeCountDownCompelete = OnTimeCountDownCompelete;
        this.timeCount = timeCountDown;
        timeOneSecondCount = 0f;
    }
    public void Init(float timeCountDown, Action OnActionOnSecondPass, Action OnTimeCountDownCompelete)
    {
        this.OnActionOnSecondPass = OnActionOnSecondPass;
        this.timeCountDown = timeCountDown;
        this.OnTimeCountDownCompelete = OnTimeCountDownCompelete;
        this.timeCount = timeCountDown;
        timeOneSecondCount = 0f;
        //初始的时候显示一次时间
        showTime();
    }
    public void showTime()
    {
        if (OnActionOnSecondPass != null)
        {
            OnActionOnSecondPass.Invoke();
        }
    }
    public void Dispose()
    {
        SelfDispose();
    }

    private void SelfDispose()
    {
        timeCountDown = 0f;
        OnTimeCountDownCompelete = null;
        timeCount = 0f;
        timeOneSecondCount = 0f;
    }
}