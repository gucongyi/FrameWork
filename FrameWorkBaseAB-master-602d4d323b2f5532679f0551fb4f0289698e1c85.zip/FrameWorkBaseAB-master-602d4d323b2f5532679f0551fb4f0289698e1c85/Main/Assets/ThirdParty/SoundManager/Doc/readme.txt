﻿For sound designer :

Sound List :
Programmers will provide to you prefabs holding a component "SoundList" (See Example/ForSoundDesigner).
You can fill this component with SoundInfo assets.
To create SoundInfo asset, right-click in the Project tab and select Create -> DPSound -> SoundInfo.

Audio Source :
Each SoundInfo will be played with a default AudioSource assigned in the slot 'Standart Audio Source' of SoundList. 
If you want to play the sound with specific settings (pitch, output mixer etc...), you can select the SoundInfo asset and
drag a new AudioSource in it.
To create a new AudioSource, right-click in the Project tab and select Create -> DPSound -> AudioSource.
