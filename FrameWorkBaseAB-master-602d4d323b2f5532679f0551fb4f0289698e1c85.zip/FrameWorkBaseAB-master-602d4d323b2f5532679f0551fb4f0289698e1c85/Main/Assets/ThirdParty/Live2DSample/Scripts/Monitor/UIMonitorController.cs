﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIMonitorController : MonoBehaviour
{
    public static UIMonitorController instance;

    #region ui component
    public EachMonitorController uiMonitorLeftTop;
    public EachMonitorController uiMonitorRightTop;
    public EachMonitorController uiMonitorLeftBottom;
    public EachMonitorController uiMonitorRightBottom;
    public Transform TransRootCurr;
    #endregion
    private void Awake()
    {
        if (instance!=null)
        {
            Destroy(instance);
        }
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
