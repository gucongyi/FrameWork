﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static MonitorHelper;
using DG.Tweening;

public class EachMonitorController : MonoBehaviour
{
    public Button ButtonMonitor;
    public Button ButtonClose;
    public EnumMonitorPos enumMonitorPos;
    public Animator animPerson;
    DOTweenAnimation[] arrayDotweenAnim;
    Transform TransSelfParent;
    bool isPause;
    

    private void Awake()
    {
        ButtonMonitor.onClick.RemoveAllListeners();
        ButtonMonitor.onClick.AddListener(OnButtonMonitorClick);
        ButtonClose.onClick.RemoveAllListeners();
        ButtonClose.onClick.AddListener(OnButtonCloseClick);
        ButtonClose.gameObject.SetActive(false);
        arrayDotweenAnim = GetComponents<DOTweenAnimation>();
        TransSelfParent = transform.parent;
        SetPause(true);
    }

    private void SetPause(bool isSetToPause)
    {
        if (isSetToPause)
        {
            isPause = true;
            animPerson.speed = 0;
        }
        else
        {//播放
            isPause = false;
            animPerson.speed = 1;
        }
        
    }

    DOTweenAnimation GetDoTweenById(string idString)
    {
        DOTweenAnimation doTweenAnim = null;
        for (int i = 0; i < arrayDotweenAnim.Length; i++)
        {
            if (arrayDotweenAnim[i].id == idString)
            {
                doTweenAnim = arrayDotweenAnim[i];
                break;
            }
        }
        return doTweenAnim;
    }
    

    private void OnButtonMonitorClick()
    {
        DOTweenAnimation doTweenEnlarge = GetDoTweenById(1 + "");
        if (doTweenEnlarge == null)
        {
            return;
        }

        //放到当前视频中
        if (UIMonitorController.instance.TransRootCurr.childCount != 0)
        {
            return;
        }
        transform.parent = UIMonitorController.instance.TransRootCurr;

        doTweenEnlarge.DORestartById(1 + "");
        ButtonClose.gameObject.SetActive(true);
        StartCoroutine(PlayToEnlageCompelete());
    }

    private void OnButtonCloseClick()
    {
        DOTweenAnimation doTweenEnlargeToNormal = GetDoTweenById(2 + "");
        if (doTweenEnlargeToNormal == null)
        {
            return;
        }


        SetPause(true);
        ButtonClose.gameObject.SetActive(false);
        doTweenEnlargeToNormal.DORestartById(2 + "");
        StartCoroutine(PlayToNormalCompelete());
        
    }

    IEnumerator PlayToEnlageCompelete()
    {
        yield return new WaitForSeconds(1f);
        SetPause(false);
    }

    IEnumerator PlayToNormalCompelete()
    {
        yield return new WaitForSeconds(1f);
        transform.parent = TransSelfParent;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
