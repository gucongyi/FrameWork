﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class MonitorHelper
{
    public const float widthEnlarge=1092f;
    public const float heightEnlarge = 1492f;
    public enum EnumMonitorPos
    {
        LeftTop,
        RightTop,
        LeftBottom,
        RightBottom
    }
}
