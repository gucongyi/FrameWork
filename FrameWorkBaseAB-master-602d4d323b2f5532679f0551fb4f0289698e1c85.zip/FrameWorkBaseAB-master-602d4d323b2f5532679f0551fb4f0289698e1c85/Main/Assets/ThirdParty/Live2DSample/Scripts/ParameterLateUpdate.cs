﻿using UnityEngine;
using Live2D.Cubism.Core;
using Live2D.Cubism.Framework;

public class ParameterLateUpdate : MonoBehaviour
{
    private CubismModel _model;
    private float _t;

    private CubismParameter _paramAngleZ;
    bool isSetParam = false;

    [SerializeField]
    public string ParameterID = "PARAM_ANGLE_Z";

    private void Start()
    {
        _model = this.FindCubismModel();
        _paramAngleZ = _model.Parameters.FindById(ParameterID);
    }

    private void LateUpdate()
    {
        _t += (Time.deltaTime * 4f);
        var value = Mathf.Sin(_t) * 30f;

        var parameter = _model.Parameters[2];

        //parameter.Value = value;
        //// Overwrite
        //parameter.BlendToValue(CubismParameterBlendMode.Override, value);

        //// addition
        //parameter.BlendToValue(CubismParameterBlendMode.Additive, value);

        //// Multiplication
        //parameter.BlendToValue(CubismParameterBlendMode.Multiply, value);

        //_paramAngleZ.Value = value;

        if (!isSetParam)
        {
            _paramAngleZ.Value = 30;
            isSetParam = true;
        }
    }
}