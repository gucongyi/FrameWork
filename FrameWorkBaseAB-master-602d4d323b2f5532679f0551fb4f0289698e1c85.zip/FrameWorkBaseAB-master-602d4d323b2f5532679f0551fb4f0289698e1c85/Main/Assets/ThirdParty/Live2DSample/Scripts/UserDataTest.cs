﻿using Live2D.Cubism.Framework.UserData;
using UnityEngine;

public class UserDataTest : MonoBehaviour
{
    private void Start()
    {
        var userDatas = gameObject.GetComponentsInChildren<CubismUserDataTag>();

        foreach (var userData in userDatas)
        {
            Debug.Log(
                "Drawable ID : " + userData.gameObject.name + "\n" +
                "Value : " + userData.Value
                );
        }
    }
}