# Live2D Proprietary Software License

## English

https://www.live2d.com/eula/live2d-proprietary-software-license-agreement_en.html

## 日本語

https://www.live2d.com/eula/live2d-proprietary-software-license-agreement_jp.html
