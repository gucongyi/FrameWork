### ライセンス

Live2D のサンプルモデルは Free Material License で提供しています。
詳細は[こちら](..\..\README.md#ライセンス)をご確認ください。