# Pose

This example is a demonstration of an animation with a Pose of a Cubism model applied by OriginalWorkflow.