# Raycasting

This sample demonstrates the raycasting functionality.
Raycasting must be set up manually, but setting it up isn't to cumbersome.
You simply have to add a ``CubismRaycaster`` component to the model game object,
and ``CubismRaycastable``s to any drawable you want to be raycastable.
