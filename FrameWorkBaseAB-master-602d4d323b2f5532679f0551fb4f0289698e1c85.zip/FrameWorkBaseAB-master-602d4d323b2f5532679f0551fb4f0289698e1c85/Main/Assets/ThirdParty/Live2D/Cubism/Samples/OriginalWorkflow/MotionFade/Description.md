# MotionFade

This example shows the fading between motions by OriginalWorkflow.

For playback in Animator, 
you need to attach a CubismFadeStateObserver to each layer.