# Async Benchmark

This scene allows simple benachmarking of the Cubism SDK.
