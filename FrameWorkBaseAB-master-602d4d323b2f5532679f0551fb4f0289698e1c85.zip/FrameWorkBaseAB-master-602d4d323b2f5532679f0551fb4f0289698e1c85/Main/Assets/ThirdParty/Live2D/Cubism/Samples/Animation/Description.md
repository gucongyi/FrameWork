# Animation

This example shows a simple Mecanim setup for a Cubism model.
