# Expression

This example shows a simple facial expression reproduction of a Cubism model with OriginalWorkflow.

Expression will be played when you click each button with the expression name.
