General users and small businesses can use this model for non-commercial purposes by agreement.  
Medium and large businesses only use for non-public testing purposes.  
When using "[License Agreement for Free Material Material](https://www.live2d.com/eula/live2d-free-material-license-agreement_en.html)" 
(License type · collaboration character)  
And here [Terms of use](https://docs.google.com/document/d/1HN9ve0zj0JCW9kOqVD4diwcLsvmKfDCJ0Xbi-5tgaEs/edit) Consent to it is necessary.
