# Motion

This example shows how to play a simple motion of a Cubism model with OriginalWorkflow.

Animation will be played when you click each button with the motion name.