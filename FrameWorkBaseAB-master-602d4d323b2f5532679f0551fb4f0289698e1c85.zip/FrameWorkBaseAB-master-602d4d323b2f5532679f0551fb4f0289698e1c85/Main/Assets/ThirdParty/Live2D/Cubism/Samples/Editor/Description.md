# Editor

This folder contains code showing how Cubism asset importing can be customized from scripts.
