﻿using UnityEngine;
using System.Collections;

namespace EasyEditor
{
    public class Weapon : MonoBehaviour {

    }
}