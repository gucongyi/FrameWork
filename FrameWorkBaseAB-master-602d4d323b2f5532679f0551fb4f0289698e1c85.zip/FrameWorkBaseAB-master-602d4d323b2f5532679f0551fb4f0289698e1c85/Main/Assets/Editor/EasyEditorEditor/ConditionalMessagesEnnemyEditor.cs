﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace EasyEditor
{
	[Groups("")]
	[CustomEditor(typeof(ConditionalMessagesEnnemy))]
	public class ConditionalMessagesEnnemyEditor : EasyEditorBase
	{
	
	}
}