﻿using UnityEditor;
using UnityEngine;
using System.Collections;

namespace EasyEditor
{
    [Groups("")]
    [CustomEditor(typeof(SetRendererOrder))]
    public class SetRendererOrderEditor : EasyEditorBase
    {
    }
}