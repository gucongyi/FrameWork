﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace EasyEditor
{
    [Groups("Attributes", "Methods")]
	[CustomEditor(typeof(ArmorBaseClass1), true)]
	public class ArmorBaseClass1Editor : EasyEditorBase
	{
	
	}
}