﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using System;
using System.Reflection;

namespace EasyEditor
{
    [Groups("")]
    [CustomEditor(typeof(NestedClassesEnemy))]
    public class NestedClassesEnemyEditor : EasyEditorBase
    {
    }
}