﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace EasyEditor
{
	[Groups("")]
	[CustomEditor(typeof(MaskEnumExample))]
	public class MaskEnumExampleEditor : EasyEditorBase
	{
	
	}
}