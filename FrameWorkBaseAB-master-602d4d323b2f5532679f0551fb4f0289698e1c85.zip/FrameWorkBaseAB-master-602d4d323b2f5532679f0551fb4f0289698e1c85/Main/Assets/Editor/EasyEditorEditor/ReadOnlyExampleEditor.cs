﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using EasyEditor;

namespace EasyEditor
{
	[Groups("")]
	[CustomEditor(typeof(ReadOnlyExample))]
	public class ReadOnlyExampleEditor : EasyEditorBase
	{
	
	}
}